describe("less.js browser tests", function() {
    testLessEqualsInDocument();
});